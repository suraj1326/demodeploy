import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BarcodeScanner from '../BarcodeScanner/BarcodeScanner';

const createNewSaleItem = () => ({
  productId: '',
  productDetails: { name: '', price: 0, stock: 0 },
  salePrice: 0,
  quantity: 1,
  itemTotal: 0,
});

const BarcodeAddSale = () => {
  const [products, setProducts] = useState([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [saleItems, setSaleItems] = useState([]);
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [orderDiscount, setOrderDiscount] = useState(0);
  const [paid, setPaid] = useState(0);
  const [orderTotal, setOrderTotal] = useState(0);
  const [totalAfterDiscount, setTotalAfterDiscount] = useState(0);
  const [showScanner, setShowScanner] = useState(false);
  const [isTableVisible, setIsTableVisible] = useState(false);

  useEffect(() => {
    axios.get('http://localhost:3000/shala/products/${id}')
      .then(response => {
        setProducts(response.data);
      })
      .catch(error => {
        console.error('Error fetching products:', error);
      });
  }, []);

  useEffect(() => {
    if (saleItems.length > 0) {
      calculateTotals(saleItems);
      setIsTableVisible(true);
    }
  }, [saleItems]);

  useEffect(() => {
    calculateTotals(saleItems);
  }, [orderDiscount, saleItems]);

  const handleProductScan = (scannedProduct) => {
    const productId = scannedProduct.id;

    axios.get(`http://localhost:3000/doll/products/${productId}`)
      .then(response => {
        const product = response.data;
        const newSaleItems = [...saleItems];
        const existingItemIndex = newSaleItems.findIndex(item => item.productId === productId);

        if (existingItemIndex !== -1) {
          newSaleItems[existingItemIndex].quantity += 1;
          newSaleItems[existingItemIndex].itemTotal = newSaleItems[existingItemIndex].salePrice * newSaleItems[existingItemIndex].quantity;
        } else {
          newSaleItems.push({
            productId: productId,
            productDetails: { name: product.name, price: product.price, stock: product.stock },
            salePrice: 0,
            quantity: 1,
            itemTotal: product.price,
          });
        }

        setSaleItems(newSaleItems);
        calculateTotals(newSaleItems);
        setShowScanner(false);
      })
      .catch(error => {
        console.error('Error fetching product details:', error);
        alert('Error fetching product details. Please check the barcode or try again.');
      });
  };

  const handleSaleItemChange = (index, field, value) => {
    const newSaleItems = [...saleItems];
    newSaleItems[index][field] = value;

    if (field === 'quantity') {
      const stock = parseFloat(newSaleItems[index].productDetails.stock) || 0;
      const quantity = parseFloat(value) || 1;
      if (quantity > stock) {
        alert('Quantity exceeds available stock. Please adjust.');
        newSaleItems[index].quantity = 1;
        newSaleItems[index].itemTotal = 0;
      } else {
        calculateItemTotal(index, newSaleItems);
      }
    } else {
      calculateItemTotal(index, newSaleItems);
    }
    setSaleItems(newSaleItems);
  };

  const calculateItemTotal = (index, saleItems) => {
    const price = parseFloat(saleItems[index].salePrice) || 0;
    const quantity = parseFloat(saleItems[index].quantity) || 1;
    saleItems[index].itemTotal = price * quantity;
    calculateTotals(saleItems);
  };

  const calculateTotals = (saleItems) => {
    const total = saleItems.reduce((sum, item) => sum + item.itemTotal, 0);
    const discountAmount = total * (orderDiscount / 100);
    const totalAfterDiscount = total - discountAmount;
    setOrderTotal(total);
    setTotalAfterDiscount(totalAfterDiscount);
  };

  const handleAddProduct = () => {
    setSaleItems([...saleItems, createNewSaleItem()]);
  };

  const handleRemoveProduct = (index) => {
    const newSaleItems = saleItems.filter((_, i) => i !== index);
    setSaleItems(newSaleItems);
    calculateTotals(newSaleItems);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const salesData = saleItems.map(item => ({
      product_id: item.productId,
      sale_price: item.salePrice,
      quantity: item.quantity,
    }));

    axios.post('http://localhost:3000/shala/sales', {
      customer_name: customerName,
      customer_phone: customerPhone,
      sales_data: salesData,
      payment_method: paymentMethod,
      order_discount: orderDiscount,
      paid
    })
    .then(response => alert(response.data.message))
    .catch(error => console.error('Error submitting sale:', error));
  };

  return (
    <div>
      {showScanner && <BarcodeScanner onProductScan={handleProductScan} />}
      <form onSubmit={handleSubmit} className="add-sale-form" id="add-sale-form">
        <h2 className="form-title">Sale Order</h2>

        <button type="button" className="new-row-btn" id="scanner-btn" onClick={() => setShowScanner(true)}>Barcode Scanner</button>
        <div className="customer-info" id="customer-info">
          <div className="input-group" id="customer-name-group">
            <label className="label" id="customer-name-label">Customer Name:</label>
            <input type="text" className="input" id="customer-name-input" value={customerName} onChange={(e) => setCustomerName(e.target.value)} required />
          </div>
          <div className="input-group" id="customer-phone-group">
            <label className="label" id="customer-phone-label">Customer Phone Number:</label>
            <input type="text" className="input" id="customer-phone-input" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} required />
          </div>
        </div>
        {/* <button type="button" className="new-row-btn" id="add-row-btn" onClick={handleAddProduct}>+ New Row</button> */}
        {isTableVisible && (
          <table className="sale-items-table" id="sale-items-table">
            <thead>
              <tr className="table-header">
                <th className="table-header-cell">#</th>
                <th className="table-header-cell">Product Name</th>
                <th className="table-header-cell">Product MRP</th>
                <th className="table-header-cell">Sale Price</th>
                <th className="table-header-cell">Quantity</th>
                <th className="table-header-cell">Stock</th>
                <th className="table-header-cell">Item Total</th>
                <th className="table-header-cell">Actions</th>
              </tr>
            </thead>
            <tbody>
              {saleItems.map((item, index) => (
                <tr key={index} className="table-row">
                  <td className="table-cell">{index + 1}</td>
                  <td className="table-cell">
                    <input
                      type="text"
                      className="input"
                      id={`product-name-${index}`}
                      value={item.productDetails.name}
                      readOnly
                    />
                  </td>
                  <td className="table-cell">
                    <input
                      type="text"
                      className="input"
                      id={`product-mrp-${index}`}
                      value={item.productDetails.price}
                      readOnly
                    />
                  </td>
                  <td className="table-cell">
                    <input
                      type="number"
                      className="input"
                      id={`sale-price-${index}`}
                      value={item.salePrice}
                      onChange={(e) => handleSaleItemChange(index, 'salePrice', e.target.value)}
                      required
                    />
                  </td>
                  <td className="table-cell">
                    <input
                      type="number"
                      className="input"
                      id={`quantity-${index}`}
                      value={item.quantity}
                      onChange={(e) => handleSaleItemChange(index, 'quantity', e.target.value)}
                      required
                    />
                  </td>
                  <td className="table-cell">
                    <input
                      type="text"
                      className="input"
                      id={`stock-${index}`}
                      value={item.productDetails.stock}
                      readOnly
                    />
                  </td>
                  <td className="table-cell">
                    <input
                      type="text"
                      className="input"
                      id={`item-total-${index}`}
                      value={item.itemTotal}
                      readOnly
                    />
                  </td>
                  <td className="table-cell">
                    <button type="button" className="remove-btn" id={`remove-btn-${index}`} onClick={() => handleRemoveProduct(index)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <div className="summary-info" id="summary-info">
          <div className="input-group" id="order-total-group">
            <label className="label" id="order-total-label">Order Total:</label>
            <input type="number" className="input" id="order-total-input" value={orderTotal} readOnly />
          </div>
          <div className="input-group" id="order-discount-group">
            <label className="label" id="order-discount-label">Discount %:</label>
            <input type="number" className="input" id="order-discount-input" value={orderDiscount} onChange={(e) => setOrderDiscount(parseFloat(e.target.value))} />
          </div>
          <div className="input-group" id="total-after-discount-group">
            <label className="label" id="total-after-discount-label">Total After Discount:</label>
            <input type="number" className="input" id="total-after-discount-input" value={totalAfterDiscount} readOnly />
          </div>
          <div className="input-group" id="paid-group">
            <label className="label" id="paid-label">Paid:</label>
            <input type="number" className="input" id="paid-input" value={paid} onChange={(e) => setPaid(parseFloat(e.target.value))} />
          </div>
          <div className="input-group" id="payment-method-group">
            <label className="label" id="payment-method-label">Payment Method:</label>
            <select className="select" id="payment-method-select" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
              <option value="Cash">Cash</option>
              <option value="UPI">UPI</option>
              {/* <option value="Online">Online</option> */}
            </select>
          </div>
        </div>
        <button type="submit" className="submit-btn" id="submit-btn">Save Sale</button>
      </form>
    </div>
  );
};

export default BarcodeAddSale;
