import React, { useState } from 'react';
import './AddSupplier.css';
import axios from 'axios';
const AddSupplier = () => {
    const [name, setName] = useState('');
    const [address, setAddress] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [email, setEmail] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.post('http://localhost:3000/branch1/mala/addSupplier', {
                name,
                address,
                phone_number: phoneNumber,
                email
            });
            alert(response.data.message);
            // Reset form
            setName('');
            setAddress('');
            setPhoneNumber('');
            setEmail('');
        } catch (error) {
            console.error('There was an error adding the supplier!', error.response ? error.response.data : error.message);
        }
    };

    return (
        <div id="add-supplier-container" className="centered-container">
            <form id="add-supplier-form" onSubmit={handleSubmit}>
                <h2 id='add-sup'>Add Supplier</h2>
                <div className="form-group">
                    <label htmlFor="supplier-name">Name:</label>
                    <input 
                        id="supplier-name"
                        className="form-input"
                        type="text" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="supplier-address">Address:</label>
                    <input 
                        id="supplier-address"
                        className="form-input"
                        type="text" 
                        value={address} 
                        onChange={(e) => setAddress(e.target.value)} 
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="supplier-phone-number">Phone Number:</label>
                    <input 
                        id="supplier-phone-number"
                        className="form-input"
                        type="text" 
                        value={phoneNumber} 
                        onChange={(e) => setPhoneNumber(e.target.value)} 
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="supplier-email">Email:</label>
                    <input 
                        id="supplier-email"
                        className="form-input"
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        required 
                    />
                </div>
                <button id="submit-button" type="submit">Add Supplier</button>
            </form>
        </div>
    );
};

export default AddSupplier;
