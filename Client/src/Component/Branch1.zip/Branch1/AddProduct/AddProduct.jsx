import React, { useState } from 'react';
import axios from 'axios';
import './AddProduct.css';

const AddProduct = () => {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [stock, setStock] = useState('');
    const [productId, setProductId] = useState('');
    const [image, setImage] = useState(null);
    const [message, setMessage] = useState('');

    const handleFileChange = (event) => {
        setImage(event.target.files[0]);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        const formData = new FormData();
        formData.append('name', name);
        formData.append('price', price);
        formData.append('stock', stock);
        formData.append('product_id', productId);
        if (image) formData.append('image', image);

        try {
            const response = await axios.post('http://localhost:3000/api/products', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            if (response.data.Status) {
                setMessage('Product added successfully!');
                setName('');
                setPrice('');
                setStock('');
                setProductId('');
                setImage(null);
            } else {
                setMessage(`Error: ${response.data.Error}`);
            }
        } catch (error) {
            console.error('Error adding product:', error);
            setMessage('Error adding product. Please try again.');
        }
    };

    return (
        <div className="add-product-overlay">
            <div id="add-product-container">
                <h1 id='addproduct-heading'>Add New Product</h1>
                <form onSubmit={handleSubmit} encType="multipart/form-data">
                    <div className="form-group">
                        <label htmlFor="image">Product Image</label>
                        <input
                            type="file"
                            id="image"
                            onChange={handleFileChange}
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="name">Product Name</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="price">Price</label>
                        <input
                            type="number"
                            id="price"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                            step="0.01"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="stock">Stock</label>
                        <input
                            type="number"
                            id="stock"
                            value={stock}
                            onChange={(e) => setStock(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="product_id">Product ID</label>
                        <input
                            type="text"
                            id="product_id"
                            value={productId}
                            onChange={(e) => setProductId(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" id="addProduct-submit-button">Add Product</button>
                </form>
                {message && <p id="message" className={message.includes('Error') ? 'error' : 'success'}>{message}</p>}
            </div>
        </div>
    );
};

export default AddProduct;
