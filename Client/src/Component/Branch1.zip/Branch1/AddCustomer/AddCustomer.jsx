import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AddCustomer.css'; // Ensure you have appropriate styles for the form

const AddCustomer = () => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');
    const [leftEye, setLeftEye] = useState('');
    const [rightEye, setRightEye] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const newCustomer = { name, phone, email, address, left_eye: leftEye, right_eye: rightEye };
        axios.post('http://localhost:3000/branch1/customers', newCustomer)
            .then(result => {
                if (result.data.Status) {
                    navigate('/Component/Branch1/CustomerList/CustomerList'); // Redirect to the customer list page
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => console.error('Error adding customer:', err));
    };

    return (
        <div className="add-customer-overlay">
        <div className="add-customer-container">
            <h2 className='add-customer-heading'>Add New Customer</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Name</label>
                    <input 
                        type="text" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label>Phone</label>
                    <input 
                        type="text" 
                        value={phone} 
                        onChange={(e) => setPhone(e.target.value)} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label>Email</label>
                    <input 
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label>Address</label>
                    <textarea 
                        value={address} 
                        onChange={(e) => setAddress(e.target.value)} 
                        required 
                    ></textarea>
                </div>
                <div className="form-group">
                    <label>Left Eye</label>
                    <input 
                        type="number" 
                        step="0.01" 
                        value={leftEye} 
                        onChange={(e) => setLeftEye(e.target.value)} 
                        required 
                    />
                </div>
                <div className="form-group">
                    <label>Right Eye</label>
                    <input 
                        type="number" 
                        step="0.01" 
                        value={rightEye} 
                        onChange={(e) => setRightEye(e.target.value)} 
                        required 
                    />
                </div>
                <button type="submit" className="addcustomer-submit-button">Add Customer</button>
            </form>
        </div>
        </div>
    );
};

export default AddCustomer;
