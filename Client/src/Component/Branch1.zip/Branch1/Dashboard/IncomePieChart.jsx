// src/components/IncomePieChart.jsx
import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import './IncomePieChart.css';

ChartJS.register(ArcElement, Tooltip, Legend);

const IncomePieChart = ({ title, totalIncome, spent, left }) => {
  const data = {
    labels: ['Spent', 'Left'],
    datasets: [
      {
        label: 'Amount',
        data: [spent, left],
        backgroundColor: ['#80bfff', '#0080ff'],
        hoverBackgroundColor: ['#99ccff', '#3399ff'],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
      },
      title: {
        display: true,
        text: `${title} ${totalIncome}`,
      },
    },
  };

  return (
    <div className="pie-chart-container">
      <Doughnut data={data} options={options} />
      <div className="pie-chart-legend">
        <div>
          <span className="legend-color" style={{ backgroundColor: '#80bfff' }}></span> Spent {spent}
        </div>
        <div>
          <span className="legend-color" style={{ backgroundColor: '#0080ff' }}></span> Left {left}
        </div>
      </div>
    </div>
  );
};

export default IncomePieChart;
