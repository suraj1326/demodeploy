// SalesSummary.js
import React from 'react';
import './SalesSummary.css';

const SalesSummary = () => {
  return (
   
    <div className="sales-summary">
      <h2>Today's Sales</h2> {/* added label */}
      <div className="summary-card total-sales">
        <div className="icon">📊</div>
        <div className="details">
          <div className="number">10850</div>
          <div className="label">Total Sales</div>
          <div className="change">+8% from yesterday</div>
        </div>
      </div>
      <div className="summary-card total-orders">
        <div className="icon">🛒</div>
        <div className="details">
          <div className="number">300</div>
          <div className="label">Total Orders</div>
          <div className="change">+5% from yesterday</div>
        </div>
      </div>
      <div className="summary-card Stocks">
        <div className="icon">📈</div>
        <div className="details">
          <div className="number">5245</div>
          <div className="label">Stocks</div>
          <div className="change">+8.2% from yesterday</div>
        </div>
      </div>
      <div className="summary-card products-sold">
        <div className="icon">📦</div>
        <div className="details">
          <div className="number">120</div>
          <div className="label">Products Sold</div>
          <div className="change">+1.2% from yesterday</div>
        </div>
      </div>
      <div className="summary-card new-customers">
        <div className="icon">👤</div>
        <div className="details">
          <div className="number">8</div>
          <div className="label">New Customers</div>
          <div className="change">+0.5% from yesterday</div>
        </div>
      </div>
    </div>
  );
};

export default SalesSummary;