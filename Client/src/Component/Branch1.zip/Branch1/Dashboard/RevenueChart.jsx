// src/components/RevenueChart.jsx
import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import './RevenueChart.css';  // Import the CSS file

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const RevenueChart = () => {
  const data = {
    labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    datasets: [
      {
        label: 'Online Sales',
        data: [15000, 20000, 5000, 20000, 15000, 10000, 25000],
        backgroundColor: 'rgba(54, 162, 235, 0.6)',
      },
      {
        label: 'Offline Sales',
        data: [10000, 15000, 25000, 10000, 12000, 10000, 7000],
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Total Revenue',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value) => `${value / 1000}k`,
        },
      },
    },
  };

  return (
    <div className="chart-container">
      <h2 className="chart-title">Total Revenue</h2>
      <Bar data={data} options={options} />
    </div>
  );
};

export default RevenueChart;
