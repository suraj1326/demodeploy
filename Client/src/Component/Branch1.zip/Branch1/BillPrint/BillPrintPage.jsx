// ParentComponent.jsx
import React, { useState, useEffect } from 'react';
import BillPrint from './BillPrint';

const BillPrintPage = () => {
  const [salesRecordNumber, setSalesRecordNumber] = useState(null);

  useEffect(() => {
    // Simulate fetching or setting salesRecordNumber
    setTimeout(() => {
      setSalesRecordNumber('27');
    }, 1000);
  }, []);

  return (
    <div>
      {salesRecordNumber ? (
        <BillPrint salesRecordNumber={salesRecordNumber} />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default BillPrintPage;
