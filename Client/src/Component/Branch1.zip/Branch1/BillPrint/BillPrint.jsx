import React, { useEffect, useState } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import './BillPrint.css'; // Ensure you have this CSS file for styling

const BillPrint = ({ salesRecordNumber }) => {
  const [billData, setBillData] = useState(null);
  const [error, setError] = useState(null);

  // Fetch sale details from the server
  const fetchSaleDetails = async (saleId) => {
    try {
      const response = await axios.get(`/bill/sales/${saleId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching sale details:', error);
      throw error;
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchSaleDetails(salesRecordNumber);
        setBillData(data);
      } catch (error) {
        setError('Failed to fetch data');
      }
    };

    fetchData();
  }, [salesRecordNumber]);

  // Calculate total amount
  const calculateTotal = () => {
    if (!billData || !billData.product_details) return 0;
    return billData.product_details.reduce((total, item) => total + item.quantity * item.salePrice, 0);
  };

  // Calculate discounted total
  const calculateDiscountedTotal = () => {
    return calculateTotal() * (1 - (billData.order_discount || 0) / 100);
  };

  // Handle print button click
  const handlePrint = () => {
    window.print();
  };

  if (error) return <p>{error}</p>;
  if (!billData) return <p>Loading...</p>;

  return (
    <div className="bill-print">
      <button onClick={handlePrint} className="print-button">
        Print
      </button>
      <div className="shop-details">
        <h1>{billData.shopName}</h1>
        <p>{billData.address}</p>
        <p>
          {billData.phone} Email: {billData.email}
        </p>
      </div>
      <div className="customer-info">
        <h2>Customer Information:</h2>
        <p>
          <strong>Name:</strong> {billData.customer_name}
        </p>
        <p>
          <strong>Phone No:</strong> {billData.customer_phone}
        </p>
        <p>
          <strong>Sales Record Number:</strong> {billData.sale_id}
        </p>
        <p>
          <strong>Date:</strong> {new Date(billData.created_at).toLocaleDateString()}
        </p>
      </div>
      <table>
        <thead>
          <tr>
            <th>Description</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {(billData.product_details || []).map((item, index) => (
            <tr key={index}>
              <td>{item.name}</td>
              <td>{item.quantity}</td>
              <td>{item.salePrice.toFixed(2)}</td>
              <td>{(item.quantity * item.salePrice).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="total-amount">
        <p>
          <strong>Total Amount:</strong> {calculateTotal().toFixed(2)}
        </p>
        {billData.order_discount > 0 && (
          <p>
            <strong>Discount:</strong> {billData.order_discount}%
          </p>
        )}
        {billData.order_discount > 0 && (
          <p>
            <strong>Discounted Total:</strong>{" "}
            {calculateDiscountedTotal().toFixed(2)}
          </p>
        )}
      </div>
      <div className="thank-you-note">
        <p>Thank you for your purchase!</p>
      </div>
    </div>
  );
};

BillPrint.propTypes = {
  salesRecordNumber: PropTypes.string.isRequired,
};

export default BillPrint;
